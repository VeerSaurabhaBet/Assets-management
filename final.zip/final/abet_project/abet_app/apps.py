from django.apps import AppConfig


class AbetAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'abet_app'
