from django.contrib import admin
from .models import Employee, Asset

admin.site.register(Employee)
admin.site.register(Asset)